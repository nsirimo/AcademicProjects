package test;

import tree.BSTNode;
import tree.BinarySearchTree;


public class Main {

	public static void main(String[] args) {
		BSTNode testNode1 = new BSTNode<Integer>(36);
		BSTNode testNode2 = new BSTNode<Integer>(20);
		BSTNode testNode3 = new BSTNode<Integer>(25);
		BSTNode testNode4 = new BSTNode<Integer>(25);
		BSTNode testNode5 = new BSTNode<Integer>(25);
		
		
		//BinarySearchTree<Integer> testTree = new BinarySearchTree<>();
		//BinarySearchTree<Character> testTree = new BinarySearchTree<>();
		//BinarySearchTree<String> testTree = new BinarySearchTree<>();
		//Integer[] testArray = { 25, 20, 36, 19, 3, 40, 10, 15, 1, 5, 16, 14 };
		//BinarySearchTree<Integer> testTree = new BinarySearchTree<Integer>(testArray);
		
		
		
		//Test Ints
//		testTree.insert(25);
//		testTree.insert(20);
//		testTree.insert(36);
//		testTree.insert(40);
//		testTree.insert(10);
//		testTree.insert(15);
//		testTree.insert(1);
//		testTree.insert(5);
//		testTree.insert(16);
//		testTree.insert(14);
//		testTree.insert(56);
//		testTree.insert(55);
//		testTree.insert(34);
//		testTree.insert(18);
		
		//Test Chars
//		testTree.insert('A');
//		testTree.insert('*');
//		testTree.insert('Y');
//		testTree.insert('2');
//		testTree.insert('1');
//		testTree.insert('3');
//		testTree.insert('c');
//		testTree.insert('e');
//		testTree.insert('G');
//		testTree.insert('W');
		
		//Test String
//		testTree.insert("Hello5");
//		testTree.insert("Hello1");
//		testTree.insert("Hello2");
//		testTree.insert("Hello3");
//		testTree.insert("Hello7");
//		testTree.insert("Hello4");
//		testTree.insert("Hello");
//		testTree.insert("Hello6");
//		testTree.insert("Hello8");
//		testTree.insert("Hello9");
//		testTree.insert("Hello10");
		
		//Test Tree is empty
//		System.out.println(testTree.isEmpty());
		
		
		//Print Tree
		//testTree.printTree();
		
		//Test Traversing 
//		System.out.println(testTree.preorder().toString());
//		System.out.println(testTree.inorder().toString());
//		System.out.println(testTree.postorder().toString());
//		System.out.println(testTree.breadthFirst().toString());
		
	}

}
